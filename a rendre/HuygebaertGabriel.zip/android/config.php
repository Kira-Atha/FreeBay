<?php
	$dbname ='local';
	$host ='localhost';
	$dsn = 'mysql:dbname:'.$dbname.';host='.$host.'\'';
	$user = 'root';
	$password = '13011974';
?>